# VYNVORI — v1.1 corrected specification (Codex application handoff)

**Status:** Proposed canonical documentation update. The founder has authorized Codex to carry out a **docs-only update**, subject to review of the resulting diff; no app implementation or automatic push/merge.

This package consolidates:
1. The original Phase 6C full technical v1.1 candidate (`VYNVORI_Technical_Blueprint_v1.1_Proposed_Amendments_Phase6C`)
2. The seven later UX-C01–UX-C07 replacements from `VYNVORI_Phase6C_Source_Aligned_UX_Corrections`.

Use **this package alone** rather than trying to apply both historical patch sets in sequence.

## Directory semantics

- `baseline/`: original canonical v1.0 snapshot; use for three-way conflict review, not overwrite.
- `candidate/`: **final corrected v1.1** root docs and `docs/technical/00–25`.
- `patches/ALL-CANONICAL-V1.1-CORRECTED.patch`: generated unified patch from baseline to corrected candidate.
- `patches/*.patch`: corresponding per-file diff files.
- `contracts/`: corrected proposed TS contracts and illustrative assertions. **NOT production runtime Zod/auth logic**. Do not install in the app or claim security validation.
- `review/`: previous change registers plus 7-correction audit and 11 unexecuted negative BFF fixture declarations.
- `validation/`: checks recorded for this consolidated package.

## Preconditions for Codex

1. Inspect `git status --short`, `git rev-parse HEAD` and current remote. Referenced Phase 6C snapshot was `83056750fe599d6a7c6b9df9ce199574b6de6eff`; do **not** assume it remains current.
2. If canonical source files diverge from `baseline/`, stop, identify divergent files and ask the founder before rebasing; never force overwrite.
3. Apply only root documentation and `docs/technical/` candidate changes. Do not replace any application, benchmark, asset, `.gitignore` or lockfile.
4. Run canonical doc/link/status/content checks, benchmark tests/typecheck, strict proposed TS compile where feasible. No paid or live external calls.
5. Show diff and evidence. **Do not commit or push without separate founder approval**.

## Historical approved policies

F-R01–F-R08 approved including amended F-R04/F-R07; Archivo and original logo preserved, Design Release 1.0 visual only, guest BYO independent, dedicated Medusa, SSO, US/AU operations. Operational blockers remain BLOCKED/NOT_STARTED.

No application code, real AI generation, commerce, printing, payments, Figma, design-release changes, output cleanup, history rewrite or production acceptance is authorized.
