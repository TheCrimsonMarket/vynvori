# Design Release 1.0 compatibility / Design Release 1.1 future acceptance

**Preserve approved visuals:** Monumental Atelier, Archivo body/editorial face, logo SVG unchanged, pale commerce/dark Studio/neutral editor, responsive typographic/campaign direction. Phase05's 94 browser checks, 71 axe runs, local fixture/sample artwork, simulated pending/errors do not establish real AI/commerce/print readiness.

**Observed source paths** in supplied visual release: `src/app.js` (hash/local navigation), `src/state.js` (local fixture), `views/creative.js` (`create`, `prompt`, `results`, `editor`, `garmentReview`), `views/storefront.js` (`bag`,`handoff`), `docs/USER-FLOWS.md`, `docs/TECHNICAL-RECONCILIATION-PENDING.md`. These remain reference components only, not implementation contracts.

**Design v1.1 separate work after approval:** map ST-00..ST-17 to server-derived `/studio` or `/studio/projects/[id]`; provide Guide/Free→brief and Director approval; promo vs paid 3+2 quote; full 0–3 cards; included refinement branch/skip; Standard unavailable/retained rights; final Use/Save/quoted revision/quality report; credit receipts and M8a cases; BYO standalone `/customize` with private sources and numeric mm controls; Medusa cart with validated shipping and QA hold. Typed mock fixtures only; no billing, source repo changes or backend proof implied.

**UX mobile criteria:** 320x480,390x568,390x844; 200% text, onscreen keyboard safe-area, no sticky button covering rights/price/cancel note, accessible comparison list, restrained ARIA live updates, no focus theft, numeric placement parity, contextual BYO back navigation.

**Dual acceptance:** Design release must pass design/UX checks using approved typed mocked contracts. Production acceptance separately requires real authoritative Medusa/SSO/AI/ledger/print/shipping evidence. Neither can confer the other's acceptance.
