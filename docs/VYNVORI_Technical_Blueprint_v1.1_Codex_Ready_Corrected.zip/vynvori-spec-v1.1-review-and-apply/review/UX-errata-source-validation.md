# Phase 6C UX correction — validation evidence

- Original Phase 6C ZIP opened and CRC-tested; all 7 source input files matched ZIP bytes before diff.
- 7 unified diff edits dry-applied with GNU `patch -p1` to a **disposable** source tree; all replacements byte-for-byte equal corrected candidates.
- TypeScript global `tsc --strict --target ES2020 --module commonjs` compiled proposed TS and assertion fixtures successfully.
- Node executable mock checks returned exit 0:
```
8 shape-negative checks plus 9 declared server-only negative scenarios; NOT real authorization acceptance
5 screen-mock checks completed; production Zod/BFF/E2E acceptance NOT_RUN
```
- `review/server-authorization-negative-fixtures.json` declares 11 **NOT_RUN** authoritative BFF negative-integration scenarios, including expiry, changed region/use, rights revocation, terms not approved, price/plan and owner changes. No BFF implementation or security test was performed.
- UX-C06 accessible screenshot, 320×480/390×568/390×844, 200% zoom, screen reader, keyboard, screen keyboard and reduced motion: **NOT_RUN**.
- Design Release 1.0 browser tests and Release 1.1 typed-mock acceptance **not independently run by this correction package**.
- This isolated package did NOT access or modify the GitHub repo. Last verified source baseline SHA is from Phase 6C, not a fresh current-head check.
- Canonical v1.0 specs, original Phase 6C v1.1 candidate, existing Design Release 1.0, logo/Archivo and existing benchmark artifacts remain untouched.
