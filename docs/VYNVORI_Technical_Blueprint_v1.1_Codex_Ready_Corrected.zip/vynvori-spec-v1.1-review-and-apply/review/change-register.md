# Phase 6C file-by-file amendment index

Baseline: `83056750fe599d6a7c6b9df9ce199574b6de6eff`; proposed, unapplied.

| File | Kind | F-R / E | Scope |
|---|---|---|---|
| `AGENTS.md` | MODIFY | F-R01..08 | agent precedence/stop gates and milestone order |
| `CODING_AGENT_START_HERE.md` | MODIFY | F-R01..08 | onboarding instructions and deferred credentials |
| `README.md` | MODIFY | F-R01..08 | top-level review boundaries |
| `docs/technical/00-master-specification.md` | MODIFY | F-R01..08 E01–06 | formal founder-approved product/offer path and separation of acceptance |
| `docs/technical/01-system-architecture.md` | MODIFY | F-R06 F-R07 E04 | component boundaries/independent authority |
| `docs/technical/02-monorepo-and-development.md` | MODIFY | F-R01..08 | review-workspace guardrails |
| `docs/technical/03-centralized-authentication.md` | MODIFY | F-R06 | auth source audit vs staging order M1a/M1b |
| `docs/technical/04-domain-database-model.md` | MODIFY | F-R01,02,04–08 E03,E05 | plan/slot/entitlement schema, QA states |
| `docs/technical/05-ai-studio-and-agents.md` | MODIFY | F-R01..08 E01,E02,E05,E06 | AI journey, Director, partial states, final, quality |
| `docs/technical/06-credit-ledger-and-entitlements.md` | MODIFY | F-R02,04–08 E01–04 | quote/ledger/rights/remedies |
| `docs/technical/07-garment-composition-editor.md` | MODIFY | F-R07 E01 | independent BYO scene/rights/lineage |
| `docs/technical/08-assets-rendering-and-dtf.md` | MODIFY | F-R07 | asset/print QA lifecycle normalized |
| `docs/technical/09-medusa-commerce-integration.md` | MODIFY | F-R02,F-R07 E01,E03 | Medusa pricing/checkout/credit boundaries |
| `docs/technical/10-cross-system-events.md` | MODIFY | F-R05–08 E02,E04 | cross-system event/cost segregation |
| `docs/technical/11-admin-qa-fulfillment.md` | MODIFY | F-R06,F-R08 E02 | unified production states and M8a support |
| `docs/technical/12-security-privacy-abuse.md` | MODIFY | F-R02,F-R07 E01,E04 | rights/data/identity controls |
| `docs/technical/13-observability-and-deploy.md` | MODIFY | F-R06,F-R08 | reconciliation ops/alerts |
| `docs/technical/14-test-strategy.md` | MODIFY | F-R01..08 E01–06 | acceptance fixtures/mobile/unknown states |
| `docs/technical/15-implementation-milestones.md` | MODIFY | F-R06 | acyclic milestone DAG with M8a gate |
| `docs/technical/16-api-contracts.md` | MODIFY | F-R01..08 E01–05 | BFF command/status APIs and guards |
| `docs/technical/17-configuration-open-gates.md` | MODIFY | F-R04–08 E01,E02 | open operational launch blockers |
| `docs/technical/18-ui-routes-and-state.md` | MODIFY | F-R01..08 E06 | canonical Next.js URLs, derived UI states |
| `docs/technical/19-notifications-analytics.md` | MODIFY | F-R06,F-R08 E02 | pre-paid notification and case requirements |
| `docs/technical/20-acceptance-matrix.md` | MODIFY | F-R01..08 E01–06 | acceptance segregation/added IDs |
| `docs/technical/21-studio-ux-screen-contract.md` | ADD | F-R01..08 E01–06 | complete Studio/connected screen contract |
| `docs/technical/22-canonical-state-machines.md` | ADD | F-R01..08 E01–06 | five independently owned state machines |
| `docs/technical/23-typed-contracts-runtime-validation.md` | ADD | F-R01..08 E03–05 | discriminated contracts + runtime validation requirement |
| `docs/technical/24-traceability-acceptance-v1.1.md` | ADD | F-R01..08 E01–06 | traceability and acceptance targets |
| `docs/technical/25-route-api-event-domain-matrix.md` | ADD | F-R01..08 | screen-route-API-domain-owner-event matrix |
