# Founder policy resolution and remaining implementation gates

## Locked; do not reopen

- F-R01=A immutable three Director directions → one purchased concept each.
- F-R02=A optional identity-bound one-preview promotion distinct from all three purchased concepts.
- F-R03=A bounded nonbillable Director planning.
- F-R04=A-amended two optional included project-bound refinements, reversible skips while open, separately quoted final, closure on verified successful final delivery with approved expiry/remedy terms.
- F-R05=A only three persisted successful concepts complete package; incomplete/unknown require recovery or operator remedy.
- F-R06=A no blind paid retries, durable reconciliation/support before paid operations.
- F-R07=A-amended paid full-journey concept package requires commercial qualified Standard final AND at least one eligible disclosed downstream digital/garment use; route loss after purchase requires preservation and approved remedy; no concept-only paid MVP.
- F-R08=A subjective dislike is not automatic refund, objective nonconformance enters case under applicable law.
- Visual approvals: Archivo + unchanged logo, Monumental Atelier, Design Release 1.0 (visual only); independent guest BYO, org SSO, dedicated Medusa Cloud, US-direct/AU-consolidated fulfillment strategy.

## No further founder architecture questions in Phase6C

All eight policies are approved. Founder action now: **review proposed v1.1 patches**, request independent Design/UX critique, then separately authorize application if acceptable.

## External/numeric operational blockers (not invented or auto-approved)

1. Actual LuckyLittleDevil source SHA & audited auth bridge and staging Medusa version before M1b.
2. Legal merchant/payment processor, tax/returns/refund terms, Medusa environment and regional selling eligibility.
3. Qualified Standard final (regional license/commercial and printability), and legally eligible downstream digital export or supplier-approved physical route, before 3+2 paid authorization. Premium qualification separate.
4. Explicit final/customer copyright and source-art rights, export permitted format/license, consent and personal-asset ownership contract.
5. Numeric customer credit unit and bundle/final price, approved package expiry/forfeiture/partial compensation, objective-defect correction limit, cancellation rules and remedies.
6. Named billing/remedy operator, numeric maximum unknown hold and notification/escalation/response SLA, audit and consumer-remedy authority before enabling live paid AI.
7. Essential Group/Dhaka DTF actual quotes and 220/240 GSM DTF physical print approval; print profile dimensions, ink/color/fonts, QA criteria and shipping paperwork.
8. Real US and AU landed shipping, duty/import/GST obligations, partner consolidated AU threshold and maximum wait, Marcus handling/dispatch SLA; no EU delivery promise.
9. Trademark clearance, artwork/brand rights and third-party model service territorial licenses.

Absent gates = flags OFF, mocks/sandbox only; never interpret founder policy approval as production activation.
