# GitHub baseline, source integrity and patch applicability

- Repo: `TheCrimsonMarket/vynvori` (private), `main`; API `git/ref/heads/main` & `commits/main` verified before preparing candidate.
- Recorded SHA: `83056750fe599d6a7c6b9df9ce199574b6de6eff` (`Add Vynvori phase-6 blueprint and brand assets`).
- Baseline source bytes: original previously authored `VYNVORI_Phase6_Coding_Agent_Handoff.zip`, extracted to the review-only `baseline/` folder. GitHub's `git/trees/main?recursive=1` lists current canonical files; full local blobs validated against reported SHA1 Git object hashes separately in validation report. No code or tracked file has been changed.
- All candidate changes are in `candidate/`, per-file patches under `patches/`, audit docs under `review/` and proposed TypeScript under `contracts/`.
- **Do not apply** until independent design review and founder follow-on authorization. Future applying agent must rerun head comparison, patch dry-run, test and rights/credential review first. A different HEAD requires new three-way review; never force-apply patch to changed source.
- The prototype release `VYNVORI-DESIGN-RELEASE-1.0(3).zip` is visual baseline only; the separate Design Release 1.1 will use typed mocks later under separate authorization. No production acceptance status changed.
